<?php

if (ALREADY_HAS_DATA) {
	echo "HAS DATA";
} else {
	echo "HASN'T DATA";
}

?>